package xyz.zionjo.common.valid;

public interface UpdateStatusGroup {
}
