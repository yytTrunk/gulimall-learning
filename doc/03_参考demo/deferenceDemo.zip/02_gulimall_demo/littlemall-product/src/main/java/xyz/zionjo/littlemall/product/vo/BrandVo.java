package xyz.zionjo.littlemall.product.vo;

import lombok.Data;

@Data
public class BrandVo {

    private Long brandId;
    private String brandName;
}
