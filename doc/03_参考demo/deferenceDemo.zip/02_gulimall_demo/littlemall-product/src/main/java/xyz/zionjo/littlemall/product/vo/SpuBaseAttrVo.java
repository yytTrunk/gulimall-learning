package xyz.zionjo.littlemall.product.vo;

import lombok.Data;

@Data
public class SpuBaseAttrVo {
    private String attrName;
    private String attrValue;
}
