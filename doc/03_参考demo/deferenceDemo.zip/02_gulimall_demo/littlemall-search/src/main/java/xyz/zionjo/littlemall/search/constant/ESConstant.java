package xyz.zionjo.littlemall.search.constant;

public class ESConstant {
    public static final String PRODUCT_INDEX = "littlemall_product";
    public static final Integer PRODUCT_PAGESIZE = 16;

}
