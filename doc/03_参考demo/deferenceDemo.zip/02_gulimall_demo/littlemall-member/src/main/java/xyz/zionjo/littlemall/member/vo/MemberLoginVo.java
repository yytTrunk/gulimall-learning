package xyz.zionjo.littlemall.member.vo;

import lombok.Data;

@Data
public class MemberLoginVo {
    private String loginAcct;
    private String password;
}
